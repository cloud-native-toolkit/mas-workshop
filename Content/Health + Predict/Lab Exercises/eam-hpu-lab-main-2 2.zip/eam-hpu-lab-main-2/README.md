# eam-hpu-lab
This respository allows you to setup a Maximo Application Suite with Monitor, Manage, Health Predict and Utilities for a fictious set of assets.   

This includes:

1. Python code to automate the setup resources in MAS. See *code* folder.
2. Sample data to create and setup the resources in MAS.  This includes asset data,  org, site and classification data.  See the *data* folder for a complete list
3. Notebooks to setup and process data that is used by theh Health Condition scores and Predict Condition scoring.  See the *Notebook* folder 
4. Instructions for using the resoureces in the git repository and using MAS Health Predict and Utilities can be found on this lab on the Web. https://mam-hol.eu-gb.mybluemix.net/apm_8.8/ 
 

