
# HPU ST model walk through

- Juan Gu - <gujuan@ibm.com>

In this exercise...

**Pre-requisites**

Ensure you have access to :
- MAS v8.7 Health and Predict Utilities
- HPU dataloader URL
- Waston studio access
- Sample ST(Substation Transformer) data for hpu, and make sure required data are loaded through dataloader via App Connect. Refer to (/img/hpu_8.7/hpu_session_01_st_sample_data_overview.png)

Where to put the sample data??

## Health and Predict Utilities out of the box models

Supported Asset classes listed in below table.


|  Asset class  | Model |
|--|--|
| DISTRIBUTION TRANSFORMER | IBM Transformers Tap Changers 4.0.0 |
| SUBSTATION TRANSFORMER | IBM Transformers Tap Changers 4.0.0,IBM Transformers Tap Changers DGA 4.0.0 |
| INSTRUMENT TRANSFORMER   | IBM Instrument Transformers Oil Filled CTs 4.0.0 |
| SWITCHGEAR | IBM Gas Insulated Switchgear 4.0.0 |
| UNDERGROUND TRANSMISSION MANHOLE | IBM Underground Transmission Manholes 4.0.0 |
| METAL SUPPORT STRUCTURE | IBM Metal Support Structures 4.0.0 |
| OVERHEAD TRANSMISSION WIRE| IBM Conductors 4.0.0 |
| POLE -  Wood Power Pole | IBM Wood Pole Structures 4.0.0 |
| CIRCUITBREAKER - Oil Circuit Breaker | IBM Circuit Breakers Oil 4.0.0 |
| CIRCUITBREAKER - Air Blast Circuit Breaker | IBM Circuit Breakers Air Blast 4.0.0 |
| CIRCUITBREAKER - Air Magnetic Circuit Breaker | IBM Circuit Breakers Air Magnetic 4.0.0 |
| CIRCUITBREAKER - Vacuum Circuit Breaker | IBM Circuit Breakers Vacuum 4.0.0 |
| CIRCUITBREAKER - SF6 Circuit Breaker | IBM Circuit Breakers SF6 4.0.0 |
| UNDERGROUNDTRANSMISSIONCABLE - High Pressure Fluid Filled Pipe Type (HPFF) Cables | IBM HPFF Cables 4.0.0 |
| UNDERGROUNDTRANSMISSIONCABLE - Mass Impregnated (MI) Cables | IBM MI Cables 4.0.0 |
| UNDERGROUNDTRANSMISSIONCABLE - Self Contained Fluid Filled (SCFF) Cables | IBM SCFF Cables 4.0.0 |
| UNDERGROUNDTRANSMISSIONCABLE - Self Contained Gas Filled (SCGF) Submarine Cables | IBM SCGF Cables 4.0.0 |
| UNDERGROUNDTRANSMISSIONCABLE - Extruded Cross Linked Polyethylene (XLPE) Cables | IBM XLPE Cables 4.0.0 |


**Note**, some asset classes have subtype, like CIRCUITBREAKER or UNDERGROUNDTRANSMISSIONCABLE


## Create a score group for ST assets
1. Login and go to Health and Predict Utilities application.
    /img/hpu_8.7/hpu_session_01_sc_setup_0.png
2. Click `Scoring and DGA settings` in the menu,in Scoring and DGA settings page, click `Create a scoring and DGA group` button.
    /img/hpu_8.7/hpu_session_01_sc_setup_1.png
3. In the create score group page,fill in name,description, select `Asset` object,choose `Connectigng group to notebook`.

    Then click `Select` to choose `IBM Transformers Tap Changers DGA 4.0.0` notebook in the notebook list dialog,click `Use notebook`.
    /img/hpu_8.7/hpu_session_01_sc_setup_2.png

    Scroll down `query` part, click `Select` to open query dialog, user can select an existing query, or click `+` button to create a new query for ST assets.
    /img/hpu_8.7/hpu_session_01_sc_setup_3.png
    /img/hpu_8.7/hpu_session_01_sc_setup_4.png

    After select the notebook and query, click `Create` to create the score group.
    /img/hpu_8.7/hpu_session_01_sc_setup_5.png

4. After score group is created, system will redirect to the score group detail page, in this page, user can see all the scores and the asset list.
    /img/hpu_8.7/hpu_session_01_sc_setup_6.png

    Click the score in the table, and active it on the right, scores need to be activated one by one based on the depedency.
    /img/hpu_8.7/hpu_session_01_sc_setup_7.png
    /img/hpu_8.7/hpu_session_01_sc_setup_8.png

5. After activing all the scores, click the `Recalculate scores` to start the analysis.


## WS notebooks and jobs





### Customize notebook model, like DGA, NOC

### Enable debug mode

### Run notebook directly for debug purpose







