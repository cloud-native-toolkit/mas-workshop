# Summary
In this Maximo Health and Predict - Utility AI Lab you wil learn how to use an existing Maximo EAM v7.6.1 instance with 
Maximo Health and Predict-Utilities in MAS v8.7 to understand the health and failure risks of your assets.  You will 
learn to:

1. Setup and asset class and  hierarchy data in Health and Predict   (Carlos Satish and Juan)
2. Create and manages assets (Web)  (Lacey and David)  
3. Understand asset health and risk
4. Predict the asset end of life (Kewei)
5. Optimize Asset Investment (John)
     
## Description
Maximo EAM includes the ability to manage assets. Reliability Engineers can use that data to better plan their asset
maintenance and repairs  however you may want to create custom machine learning models to make predictions
or classifications using asset data. With Auto AI the process of selecting the right model and identifying the right
feature inputs to make metric prediction is greatly simplified.

The intended audience for this tutorial are developers who will set up the Maximo Environment, data scientists who would 
like to analyze their data to create prediction models for asset end of life using Predict model templates.  Reliability 
Engineers who need to plan to address poor asset health and risk with an asset investment plan to repair or replace the 
assets.

Out of scope:
(Maximo Spatial)

### Asset Data 

You must first set up your environment with asset data used in the lab.  You will create `X` assets `11111096` and 
`111137F8`.  Some assets will have timeseries metered data that will be used to predict failures.   The lab provides a 
Python script `x_simulator.py` to send asset meter data to the `X` assets.  This lab includes real `X` device data in 
the csv file named `tbd_data.csv`.  

The  data metric readings include:  TBD 

|   Metric Name        | Metric Description                                               |
|----------------------|------------------------------------------------------------------|
|   evt_timestamp      | Reading timestamp metric data was read by sensor                                               |
|   speed	           | Pump impeller speed                                              |
|   head               | Pump head                                                        |
|   device_id          | The device identifier for the 2 pump devices 11111096 and 111137F8|
|   pump_mode          | Pump mode a for automatic or h for manually operated by hand     |
|   flow               | Pump flow                                                        |
|   voltage            | Pump voltage                                                     |
|   POWER              | Pump power consumption                                           |
|   CURRENT            | Pump current                                                     |


**Pre-requisites**

Ensure you have access to :
- MAS v8.7  Health and Predict
- Cloud Pak for Data Watson Studio
- App Connect for IBM Cloud
- Asset Class Data and Scripts for the Labs provided by the Instructor

# Exercises

This lab includes the following exercises which include the instructions for doing this lab

## Load Data 

This lab includes asset data for doing the exercises.  Here are the asset classes included with this lab:

| Asset                            |
|----------------------------------|
| Pump                             |
 |

Choose one of the following ways to load this data into HPU:

A. [Data Loading Using Python](dataload_python.md)

B. [Data Loading Meter Using EAM CronTask](dataload_crontask.md)

C. [Data Loading Using App Connect](dataload_appconnect.md) 


## Manage Assets
1. Creating a New Asset in Maximo in Web UI Ready for author. Contributor?
2. Associating Meters w/ an Asset in Web UI
3. Creating New Condition Monitoring Points & Job Plans
4. Create a Saved Query or Asset Group*
5. Edit the IOTHISTORIAN Cron Task & External Systems- With MAS is there a new way to upload Asset data from core to health? yes how?

## Understand Asset Health
1. Setup health scores and groups for assets and locations
3. Create historical work orders for Asset Timeline and scheduled preventive maintenance.
4. View Asset Health Ready for author. Contributor?
5. Compare Asset Investment Strategies. ( Optional for customers who have Utilities)
6. Action Assets. View low health work queue, select the first item, View asset health on asset detail page review the scores, and take action by opening a work order in EAM.

## Predict Asset Failures
1. Create asset group
2. Set-up predictive end of life models reference https://ibm.box.com/s/asiynz44rt0sd9alt9wnj9a0ris0fnx2
3. Explain asset failure predictions

##  Optimize Asset Investment and Risk
1. Compare Asset Investment Strategies. Understand costs associated with Refurbishment and Replacement Planning and the long term impact on Asset health. 
2. Analyze long term asset risk for a selected investment strategy.

## Architecture

Here is the Architecture flow for this tutorial
![Deployment Pattern](./img/architecture.png)
