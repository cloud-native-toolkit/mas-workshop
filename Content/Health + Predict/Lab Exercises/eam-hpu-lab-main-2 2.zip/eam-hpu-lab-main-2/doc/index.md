# Welcome to the IBM Maximo H&P App Connect Lab<br>(Version: 1.0)

You will learn about

* Installation and Configuration of IBM App Connect
* Creation of Integration server with-in App Connect
* App Connect is the required to setup Maximo Health & Predict - Utilities (H&P) Module

Imporant Note.

* App Connect that is installed as part of OpenShift is supported currently

**Updated: 2021-04-12**

---