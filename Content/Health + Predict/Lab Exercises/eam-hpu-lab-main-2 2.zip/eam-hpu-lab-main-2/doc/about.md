
# Contributors to IBM Maximo Template

- Juan Gu - <gujuan@cn.ibm.com>
- Satish Narasimha - <ssnarasi@in.ibm.com>

---

# Change Information

|Date      |By                | Description                                             |
|:---------|:-----------------|:--------------------------------------------------------|
|2022-04-14|Juan Gu / Satish  |Added the About page and Updated information into Index. |

---
