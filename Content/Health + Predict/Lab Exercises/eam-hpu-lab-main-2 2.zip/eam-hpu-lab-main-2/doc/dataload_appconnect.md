# Data Load App Connect

In this exercise you will load asset class data into Health Predict and Utilities using App Connect on IBM Cloud

**Pre-requisites**

Ensure you have access to :
- MAS v8.7  Health and Predict
- App Connect for IBM Cloud
- Asset Class Data and Scripts for the Labs provided by the Instructor
- App Connect Bar File provided by the Instructor

## Deploy the BAR File
<a name="setup_python"></a>
The Bar file includes a UI for loading data using App Connect integration flows. 


- [Install and Create a Virtual Environment](#install_ve)  for Python v3.9

- [Setup and Activate a Virtual Environment](#activate_ve)  Install Python dependencies, clone repository 
    and verify environment

- [Download, Install and Configure PyCharm](#pycharme)  

!!! note
    These directions for are a Mac. Using Python v3.9 for Maximo Application Suite v8.7.
    Download Python for Windows at  https://www.python.org/downloads/windows/ 