# Setup Watson Studio

In this exercise you will Setup Watson Studio to Run Notebooks to load data into Health and Predict and also develop
models that you will use.

- [Get URL and User credentials](#get-credentials) to access Watson Studio.
- [Create a project](#create-project) and add the setup notebook to your project in Watson Studio.
- [Setup Database Connection]("db-connection") to allow Watson Studio to access DB.
- [Get URL to Download the Healh and Predict Notebooks](download_URL).
- [Download the Predict Notebooks]("setup-studio") to Watson Studio Project.
- [Update and Run Setup Notebooks](#run-notebook) to create asset types in Health and Predict.

## Get URL and User credentials to access Watson Studio
<a name="get-credentials"></a>

Ask your Maximo Application Suite administrator to get your user name and password for Watson Studio,
API keys and URL that you will use to connect to Watson Studio.

1. Login to Maximo Application Suite.  Click on `Adminstration`
![setup assets](/img/eam-hpu-lab/p01.png) 

2. Click on `Configurations` and `Watson Studio`
![setup assets](/img/eam-hpu-lab/p02.png) 

3. Click on `System`  Make note of the URL, user name and password.  You will use it to login to Cloud Pak for Data. 
![setup assets](/img/eam-hpu-lab/p03.png)

4. Open a browser to the URL and use the credentials from the previous steps to login to Cloud Pak for Data.  After logging in you see your Watson Studio Overview page.
![setup assets](/img/eam-hpu-lab/p04.png) 


## Create a Project in Watson Studio
<a name="create-project"></a>
Setup database security to allow Watson Studio to access the database.   Follow the instructions in the documentation

Create a project](#create-project) and add the setup notebook to your project in Watson Studio.

1. Click on 'All Projects' where you will then create a new project.
![setup assets](/img/eam-hpu-lab/p05.png) 
 
2. Click 'New Project'. 
![New Project](/img/eam-hpu-lab/p06.png) 

3. Accept default and click 'Next'. 
![Default Value](/img/eam-hpu-lab/p07.png) 

4. Click 'New Empty Project'. 
![New Empty Project](/img/eam-hpu-lab/p08.png)

5. Enter a project name and description.
![setup assets](/img/eam-hpu-lab/p09.png) 

6. Click `Add to Project`.
![setup assets](/img/eam-hpu-lab/p10.png) 

7. Choose `Notebook`.
![setup assets](/img/eam-hpu-lab/p11.png) 

8. Choose `From File`.
![setup assets](/img/eam-hpu-lab/p12.png) 

9. Click `Create` button.
![setup assets](/img/eam-hpu-lab/p12.png) 


## Setup Database Connection in Watson Studio
<a name="db-connection"></a>
Setup database security to allow Watson Studio to access the database.   

1. Follow the instructions in the documentation to download the [Database PEM file](https://www.ibm.com/docs/en/mhmpmh-and-p-u/8.5.0?topic=started-getting-application-administrators#concept_ir4_mc2_jmb__db2cert)

2. Open a separate browser  window and login to Cloud Pak For Data Console  to get the database pem file.  Click on 
Click on the `Hamburger` menu, `Instances` Select the database name used by Maximo Monitor.
![Database instance](/img/eam-hpu-lab/p20.png) 

3. Click on `Console` to download  the database pem file.  If you receive an error saying the console hasn't been provisioned ask your IT Administrator to install it.
![Console](/img/eam-hpu-lab/p21.png) 

4. Click on the `Download SSL Certificate`
![Download](/img/eam-hpu-lab/p23.png) 

5. Return to the browser with Watson Studio Project you created earlier. Add the database pem file as a data asset.  Drag and drop the database pem file into the data assets 
![drag pem file](/img/eam-hpu-lab/p22.png) 


## Get URL to Download the Healh and Predict Notebooks
<a name="download_url"></a>
The Health and Predict notebooks require programmatic access and credentials to access Maximo Application Suite.  You will need these values to create the URL that allows you to download the Health and Predict notebooks zip file.  The URL looks  like:

https://`EXTERNAL_APM_API_BASEURL`/ibm/pmi/service/rest/ds/`APM_ID`/`APM_API_KEY`/file/download

These notebooks templates are what you use to calculate asset health and risk scores, asset end of life probability, anomaly detection, predict failure dates and more.  

| Environment Variable | Find It In                                                                                                         |
|--------------------------|--------------------------------------------------------------------------------------------------------------------|
| APM_ID	                  | The value for the mxe.PMIId system property.                                                                       |
| APM_API_BASEURL	         | The root of the URL value for the PREDICTAPI endpoint.                                                             |
| EXTERNAL_APM_API_BASEURL | The route location for the application project in Red Hat® OpenShift® Container Platform.  APM_API_KEY	An API key. |
| APM_API_KEY              | The API key from Integration                                                                                       |

### Get mxe.PMIId value for APM_ID
1. To get the value of mxe.PMIId, open a browser and access the Health and Predict application.  See below example of where you can find these values in Health and Predict system properties.  Click on `Application Administration` 
![system properties](/img/eam-hpu-lab/p26.png) 

2. Click on `System Configurations`, `Platform Configurations` and `System Properties`.   Click on `Funnel` icon to filter properties that begin with `property name` PMI.
![PMI Search](/img/eam-hpu-lab/p25.png) 

Something like:
`APM_ID` = `mxe.PMIId` = f31a8r48


### Get APM_API_BASEURL from the value from PREDICTAPI endpoint
1. To get  `APM_API_BASEURL` from the value from `PREDICTAPI endpoint`. You can find `endpoints` in Health and Predict Adminstration application by searching on `End Points`.  Click on `Application Administration` 
![Adminstration](/img/eam-hpu-lab/p26.png) 

3. Click in search field and search application for `End Points` 
![End Points](/img/eam-hpu-lab/p35.png) 

4. Note the URL for the `PREDICTAPI` endpoint.
![End Points](/img/eam-hpu-lab/p34.png) 

Something like:
`APM_API_BASEURL` = `PREDICTAPI` endpoint = https://main.predict.ivt11rel87.ivt.suite.maximo.com

### Get EXTERNAL_APM_API_BASEURL value using Openshift

1. To get root of the URL value for the PREDICTAPI endpoint, open a browser and access the Openshift Console MAS is deployed on. 
For IBM Cloud deployments goto `https://cloud.ibm.com`, select your `account` from the drop down menu and click `Clusters`
![IBM Cloud Account](/img/eam-hpu-lab/p29.png) 

2. Under `Resources` click on your cluster resource.
![Choose Cluster Resource](/img/eam-hpu-lab/p30.png) 

3. Click on `Openshift Web Console`
![Openshift Console](/img/eam-hpu-lab/p31.png) 

4. Click on `Projects`. Search on `Predict` and Click on `Project`
![Choose Cluster](/img/eam-hpu-lab/p33.png) 

Then what??

5. Trim the URL to get the  `APM_API_BASEURL`  by removing `/ibm/pmi/service/rest`. Your `APM_API_BASEURL` should look something like:

Something like:
`EXTERNAL_APM_API_BASEURL` = https://ivt_context_rel87-predict-api.mas-host-predict.svc


### Get APM_API_KEY using ??

1. To get `APM_API_KEY`, open a browser and access the Openshift Console MAS
![Choose Cluster](/img/eam-hpu-lab/p34.png) 

EXTERNAL_APM_API_BASEURL = https://main.predict.ivt11rel87.ivt.suite.maximo.com

APM_API_KEY = n7gsskljdfksjdfkjsdkljfs98374837486967jm8

3. Go to Openshift Console to get the Service endpoints?
https://main.predict.rel87.suite.maximo.com

4. Make note of the values and create the URL you can use in the browser to download the zip file. 
Here is an example download URL for Predict model notebook templates zip file using the values from the previous steps. 

https://`EXTERNAL_APM_API_BASEURL`/ibm/pmi/service/rest/ds/`APM_ID`/`APM_API_KEY`/file/download
https://main.predict.rel87.suite.maximo.com/ibm/pmi/service/rest/ds/f31a8r48/n7gsskljdfksjdfkjsdkljfs98374837486967jm8/file/download

Save the zip file locally.

4. Return to your Cloud Pak for Data project and upload the models.
![setup assets](/img/eam-hpu-lab/p26.png) 

5. Click on `System Configurations` and `System Properties`
![setup assets](/img/eam-hpu-lab/p02.png) 

Example URL

https://masws.predict.ivt09rel86.ivt.suite.maximo.com/ibm/pmi/service/rest/ds/13f9a43a/7n1okjdknc3e[…]7vj5j1ak5ljppehd2t/lib/download?filename=pmlib

## Download and add Predict Notebooks to Watson Studio Project
<a name="setup-studio"></a>