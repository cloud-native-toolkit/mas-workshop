# Objectives
In this Exercise you will learn how to:

* Do something else
* Do something wildly complex in an easy way
