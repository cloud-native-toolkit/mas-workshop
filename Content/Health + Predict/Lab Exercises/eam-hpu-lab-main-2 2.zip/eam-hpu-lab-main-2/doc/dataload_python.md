# Data Load Python

In this exercise you will:
1. [Setup Watson Studio to Run Notebooks](#setup_watson)
2. [Load data into Health Predict and Utilities using Python scripts](#loaddata_python)

## Setup Watson Studio to Run Notebooks
<a name="setup_watson"></a>

- [Install and Create a Virtual Environment](#install_ve)  for Python v3.7

- [Setup and Activate a Virtual Environment](#activate_ve)  Install Python dependencies, clone repository 
    and verify environment

- [Download, Install and Configure PyCharm](#pycharme)  

!!! note
    These directions for are a Mac. Using Python v3.9 for Maximo Application Suite v8.7.
    Download Python for Windows at  https://www.python.org/downloads/windows/ 
    
### Install and Create a Virtual Environment
<a name="install_ve"></a>

1. Install Python v3.9  using this tutorial https://python.tutorials24x7.com/blog/how-to-install-python-3-9-on-mac

2. Download Python For Mac https://www.python.org/downloads/macos/  file name is `python-3.9.10-macos11.pkg`

3. Verify install by opening terminal window and checking the Python version
    ```
    python3 --version
    ```
 
4. Install "pip". (Python Package Installer):
    ```
    sudo easy_install pip  # for Mac try also removing sudo from the command
    ```

5. Install virtual environment to keep dependencies separate from other projects
     ### For Mac
     ```
     sudo pip install virtualenv 
     ```
     ### For Windows
     ```
     pip install virtualenv      
     ```

6. Create a virtual environment use Python 3.9 that you just installed named apm-python39
    ```
       python3 -m venv apm-python39
    ```
   
###  Activate a Virtual Environment
<a name="activate_ve"></a>

1.  Open a new terminal window and change directory to your Virtual Environment directory.

    ```
    cd apm-python39
    ```

2.  Activate your virtual environment.

    ###  For Mac

    ```
    source bin/activate  
    ```

    ###  For Windows

    ```
    .\Scripts\activate   
    ```

3.  The result in `Terminal` should be something like:

    ###  For Mac

    ```
    (apm-python39) My-Mac: myuserid$
    ```

4.  Install Git.  

    ### For Windows
    See https://git-scm.com/download/win  
    
    ###  For Mac
    The easiest is to install the Xcode Command Line Tools.

5. Clone the github repository name provided by the instructor.

    ```
    git clone https://github.com/repo_name_provided
    cd hpu-lab
    ```

6.  Within your project directory in the activated virtual environment, install Monitor Python Custom Functions SDK and 
dependencies.  

    ```
    pip install -r requirements.txt
    ```

7.  Apply export variables in terminal for DYLD_LIBRARY_PATH for DB2 jars on Mac OS X only.

    ###  For Mac

    ```
    cd "<replace with the git cloned project directory name>"
    export DYLD_LIBRARY_PATH=<"replace with your virtual env directory>"/lib/python3.7/site-packages/clidriver/lib:$DYLD_LIBRARY_PATH
    export DYLD_LIBRARY_PATH=/Users/carlosferreira/ve/iot-python3/lib/python3.7/site-packages/clidriver/lib:$DYLD_LIBRARY_PATH
    ``` 

8.  Set PYTHONPATH to your project directory where you installed your virtual environment.

    ###  For Mac

    ```
    export PYTHONPATH="<replace with your root_project_directory>"/maximo_autoai 
    export PYTHONPATH=/Users/carlosferreira/Documents/AutoAILabs/iot-python3/maximo_autoai 
    ```

9.  Go to  API to get key and token  `TODO Directions `


### Install and Launch Jupyter 
<a name="jupyter"></a>

Jupyter is an open-source web application that allows you to create and share documents that contain live code, equations, 
visualizations and algorithms for working with AI Models and functions.

1.  Install Jupyter using [instructions](https://jupyter.org/install) Use the `Pip Install` option.

2.  Start Jupyter Notebook process.  Using a similar example steps below.

    ```
    cd /Users/student01/ve/iot-python3/bin
    source activate
    cd /Users/student01/MAS_AutoAI
    export PYTHONPATH=/Users/student01/MAS_AutoAI
    export DYLD_LIBRARY_PATH=/Users/student01/ve/iot-python3/lib/python3.7/site-packages/clidriver/lib:$DYLD_LIBRARY_PATH
    ```

3. Launch Jupyter Notebook to edit Linear Regression Models.

    ```
    jupyter notebook
    ```

This opens a Jupyter notebook in the new browser window that opened.  Browse to the `notebooks` folder. Click on the `notebook` 
to view the Notebook.

### Download, Install and Configure PyCharm
<a name="pycharm"></a>

Using an integrated development environment helps improve developer productivity when writing Python scripts and Monitor 
Custom Functions.  It is recommended that you download and install [Pycharme Community Edition](https://www.jetbrains.com/pycharm/download/#section=mac). 
It is a free IDE.  To run Python Scripts in  you should configure your Python Environment for each script you would like 
to run to reference the virtual environment you setup earlier.

1. Follow the instructions to install Pycharm Community Edition.

2. Start Pycharm.

3. In the `Project` view, right click on the Python script file you want to run.  Select `edit configurations`.   See the
example settings below.
![setup assets](/img/monitor_autoai_8.4/l19.png) 

4. Set the Python Environment variable similar to what is  shown below. It should reflect the installation directory of your virtual environment.

    ```
    PYTHONUNBUFFERED=1;DYLD_LIBRARY_PATH=/Users/student01/ve/iot-python3/lib/python3.7/site-packages/clidriver/lib:$DYLD_LIBRARY_PATH;PYTHONPATH=/Users/student01/MAS_AutoAI
    ```
    
5. Set the `Python interpreter` to your virtual environment.  If you don't have one create Python interpreter using the virtual envrionment you created earlier.

## Load Data Using Python
<a name="loaddata_python"></a>