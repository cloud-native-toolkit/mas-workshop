# Pre-Requisite Instructions

Here are the required pre-requisites for the App Connect Setup.

# All Exercises

Below App Connect Exercises require that you have:

1.  Need to have OpenShift Ver 4.6 or 4.8 installed & Administration access to OpenShift Platform<br>

2.  Verify IBM App Connect operator available in OpenShift Platform<br>
If IBM App Connect is not available as "Operator", then we need to get it make available using standard operator

![img](img/hpueu_8.7/App_Conn_Operator.png)

2a.  If Operator is not available, use below to get operator made available in OpenShift Platform<br>
[Operator-Link]
(https://www.ibm.com/docs/en/app-connect/containers_cd?topic=access-enabling-operator-catalog)

3.  User access to a Maximo Application Suite environment.<br>
Your Exercise facilitator should have provided you with the information on your access.<br>

4.  An IBM ID.  If you don't have an IBM ID you can get one [here](https://www.ibm.com/account/reg/signup?):<br>
o Click `Login to MY IBM` button<br>
o Click `Create an IBM ID` link<br>

4.  Test your access to the Maximo Application Suite environment