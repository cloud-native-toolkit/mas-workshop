#!/bin/bash
orgid=EUORG1
siteid=EUDEMO
path='/Users/gujuan/Documents/work/work/2022/lab/Github/eam-hpu-lab/csv-files/hpu_csv_st'

# ## Note, create a new org and site is different when comes to a different language env.
# ## E.g, this sample python will not work on jpn env, need use 0_createOrgAndSite-jpn.py.
python3 0_createOrgAndSite.py $orgid $siteid | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 1_loadClassifications.py $orgid $siteid $path/1.classification | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 2_loadDomain.py $orgid $siteid $path/2.domains | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 3_loadMeters.py $orgid $siteid $path/3.meters/meterGroups | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 4_loadLocations.py $orgid $siteid $path/4.locations/'4.0 container' 5 10 | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 4_loadLocations.py $orgid $siteid $path/4.locations  5 10 | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 5_loadAsset.py $orgid $siteid $path/6.assets 5 10 | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 6_loadReading.py $orgid $siteid $path/5n7.readings/7.assetMeterReading  5 10  | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 6_loadReading.py $orgid $siteid $path/5n7.readings/5.locationMeterReading 5 10 | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 7_loadLocSystem.py $orgid $siteid $path/8.locSystem 1 10 | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 8_updateLocHierarchy.py $orgid $siteid $path/9.containment 1 10 | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

python3 9_loadMapContainerCfg.py $orgid $siteid $path/10.containerConfiguration 5 10 | tee log.txt
if grep -q "'status': '400'" log.txt; then exit 1; fi

#Clean log file
rm -f log.txt