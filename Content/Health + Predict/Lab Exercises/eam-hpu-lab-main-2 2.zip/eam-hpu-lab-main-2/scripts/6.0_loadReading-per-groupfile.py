import sys,os
import  api
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import time
import csv 
import json 
import glob
import pandas as pd	
from datetime import datetime

orgid=sys.argv[1]
siteid=sys.argv[2]
r_file = sys.argv[3]
assetAPI='MXAPIASSET'
locationAPI='MHOPERLOC'

batchSize=250
thread=1

if len(sys.argv) > 4:
    batchSize = int(sys.argv[4])

def bulk_create(items):
    meterAPI=locationAPI
    arr=[]
    obj={}
    for item in items:
        obj={}
        meterObj={}
        meterObj["metername"]=item["METER"]
        meterObj["newreading"]=item["VALUE"]
        meterObj["newreadingdate"]=item["TIMESTAMP"]
        meterObj["linearassetmeterid"]=0
        if 'ASSETNUM' in item.keys():
            obj["assetnum"]=item["ASSETNUM"]
            obj["assetmeter"]=meterObj
            meterAPI=assetAPI
        else:
            obj["location"]=item["LOCATION"]
            obj["locationmeter"]=meterObj
   
        obj["siteid"]=siteid
        obj["orgid"]=orgid
        obj["_action"]='AddChange'
        # print(obj)
        arr.append(obj)
    # print(len(arr))
    # print(arr)
    # return ""

    res = api._maximo_bulk_create(mxapp=meterAPI, payload=arr)
    print("response status code : "+str(res.status_code))
    print(res.json())
    return res.status_code
    # return 200
    
path, filename = os.path.split(r_file)  

csv_file = pd.DataFrame(pd.read_csv(r_file, sep = ",", header = 0, index_col = False))
csv_file.to_json(path+"/"+filename+".json", orient = "records", date_format = "epoch", double_precision = 10, force_ascii = True, date_unit = "ms", default_handler = None)

input_file = open(path+"/"+filename+".json")
array = json.load(input_file)
# print(array)
batch_list = [array[x:x+batchSize] for x in range(0, len(array),batchSize)]

processes = []

with ThreadPoolExecutor(max_workers=thread) as executor:
    for items in batch_list:               
        processes.append(executor.submit(bulk_create, items))
for task in as_completed(processes):
    if str(task.result()) != str(200):
        print(task.result())


#Clean 
os.remove(path+"/"+filename+".json")    
os.remove(r_file)    