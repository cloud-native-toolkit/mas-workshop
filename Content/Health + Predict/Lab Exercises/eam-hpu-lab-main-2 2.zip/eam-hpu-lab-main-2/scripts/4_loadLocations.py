import sys,os

from attr import attributes
import api
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import time
import math 
import json 
import glob
import pandas as pd	
from datetime import datetime

orgid=sys.argv[1]
siteid=sys.argv[2]
path = sys.argv[3]
locationAPI='MHOPERLOC'
entries = glob.glob(path+'/*.csv')

batchSize=100
thread=10

if len(sys.argv) > 5:
    thread = int(sys.argv[4])
    batchSize = int(sys.argv[5])

# Prepare attributes
# Prepare datatype
parms={'oslc.select':'*','oslc.where':'domainid="DATATYPE"'}
resp=api._maximo_query("MHDOMAIN",parms);
datatypes=resp.json()['member'][0]['synonymdomain']
# print(datatypes)

parms={'oslc.select':'assetattrid,datatype'}
resp=api._maximo_query("MXAPIASSETATTRIBUTE",parms);
attrsArr=resp.json()['member']
attrDict={}
for attr in attrsArr:
    key = attr['assetattrid']
    for dt in datatypes:
        # print(dt)
        # print()
        if dt['value'] == attr['datatype']:
            if dt['maxvalue'] == 'ALN':
                attrDict[key]='alnvalue'
            elif dt['maxvalue'] == 'NUMERIC':
                attrDict[key]='numvalue'
            break;
# print(attrDict) 

def bulk_create(items):
    # Prepare meters based on metergroup
    hasMeterGroup=False
    metergroups=[]
    metergroupsCondition="["
    for item in items:
        # print(item)
        if 'GROUPNAME' in item.keys():
            if item['GROUPNAME'] not in metergroups and item['GROUPNAME'] is not None:
                metergroups.append(item['GROUPNAME'])
                hasMeterGroup = True
    for mg in metergroups:
        metergroupsCondition=metergroupsCondition+'"'+mg+'",'
    metergroupsCondition=metergroupsCondition[:-1]
    metergroupsCondition=metergroupsCondition+"]"

    groupMeterDict={}
    if hasMeterGroup:
        parms={'oslc.select':'groupname,meteringroup{metername}','oslc.where':'groupname in '+metergroupsCondition}
        # print(parms)
        resp=api._maximo_query("MHMETERGROUP",parms);

        for g in resp.json()['member']:
            meters=[]
            for m in g['meteringroup']:
                mobj={}
                mobj['metername'] = m['metername']
                mobj['linearassetmeterid'] = 0
                mobj['_action'] = 'AddChange'
                meters.append(mobj)
            groupMeterDict[g['groupname']]=meters

    # print(groupMeterDict['ST_MG'])
    arr=[]
    for item in items:
        classification=""
        obj={}
        specObjArr=[]
        for k in item.keys():
            value = item[k]
            if value is not None:
                if 'SPEC.' in k:                
                    specObj={}
                    specObj['assetattrid']=k.split('SPEC.')[1]
                    specObj[attrDict[k.split('SPEC.')[1]]]=value
                    specObjArr.append(specObj)
                elif k !='CLASSIFICATIONID' and k != 'GROUPNAME':
                    obj[k.lower()]=item[k]
                elif k == 'CLASSIFICATIONID':
                    classification = value.upper()
                elif k == 'GROUPNAME':
                    obj['locationmeter']=groupMeterDict[value]

        obj["locationspec"]=specObjArr
        obj["siteid"]=siteid
        obj["orgid"]=orgid
        if 'hierarchypath' in item and item['hierarchypath'] is not None:
            obj['hierarchypath']=item['hierarchypath']
        else:
            obj['hierarchypath']=classification
        obj['_action']='AddChange'

        arr.append(obj)
    # print(arr)
    res = api._maximo_bulk_create(mxapp=locationAPI, payload=arr)
    print("response status code : "+str(res.status_code))
    print(res.json())
    return res.status_code


now = datetime.now()
now_string = now.strftime("%d/%m/%Y %H:%M:%S")
start = time()

for file in entries:
    print("-------------------------------------------------------------------------------------------------")
    print("  Start load locations defined in :"+file)
    print("-------------------------------------------------------------------------------------------------")

    csv_file = pd.DataFrame(pd.read_csv(file, sep = ",", header = 0, index_col = False))
    csv_file.to_json("./temp.json", orient = "records", date_format = "epoch", double_precision = 10, force_ascii = True, date_unit = "ms", default_handler = None)

    input_file = open("./temp.json")
    array = json.load(input_file)
    batch_list = [array[x:x+batchSize] for x in range(0, len(array),batchSize)]

    processes = []
    with ThreadPoolExecutor(max_workers=thread) as executor:
        for items in batch_list:
            processes.append(executor.submit(bulk_create, items))

    for task in as_completed(processes):
        if str(task.result()) != str(200):
            print(task.result())

print("Start at:"+now_string)	
print("End at :"+datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
seconds = time() - start
m, s = divmod(seconds, 60)
print('Time taken: '+str(math.trunc(m))+" minutes"+" and "+str(math.ceil(s*100)/100)+" seconds")

#Clean 
os.remove("./temp.json")
