import sys,os
from time import time,sleep
import math 
import glob
import pandas as pd	
from datetime import datetime
from os.path import exists
import shutil

orgid=sys.argv[1]
siteid=sys.argv[2]
path = sys.argv[3]
entries = glob.glob(path+'/*.csv')

now = datetime.now()
now_string = now.strftime("%d/%m/%Y %H:%M:%S")
start = time()

batchSize=250
thread=10

if len(sys.argv) > 5:
    thread = int(sys.argv[4])
    batchSize = int(sys.argv[5])

def _splitToGroups(org_file,siteid,groupnum,folder):
    #----------------------------------------------Run only once ----------------------------------------------------
    #Split org file into batchSize number files to process in parallel. 
    #Split based on hash
    filename = os.path.basename(org_file)
    path = os.path.dirname(org_file)
    temppath = os.path.join(path, "tmp/")

    if folder is not None:
        temppath=folder
    if exists(temppath):
        shutil.rmtree(temppath)
    os.mkdir(temppath)
    groupFiles=[]
    df = pd.DataFrame(pd.read_csv(org_file, sep = ",", header = 0, index_col = False))
    columns=df.columns
    key = 'LOCATION'
    if 'ASSETNUM' in columns:
        key = 'ASSETNUM'
    
    for i, row in df.iterrows():
        # print(df.at[i,'LOCATION'])
        #group files
        sum = 0
        mul = 1
        record=df.at[i,key]+siteid
        # print(len(record))
        # Hash code
        for j in range(len(record)):
            mul = 1 if (j % 4 == 0) else mul * 256
            sum += ord(record[j]) * mul
        # Reading file name based on hash
        file=temppath+filename+"-"+str(sum%int(groupnum));
        file_exists = exists(file)
        if file not in groupFiles:
            groupFiles.append(file)

        if file_exists == False:
            header=key+',METER,TIMESTAMP,VALUE'
            text_file = open(file, "a")
            # # print(sum%group);
            text_file.write(header+"\n")
            text_file.close()
        line=df.at[i,key]+","+df.at[i,'METER']+","+df.at[i,'TIMESTAMP']+","+str(df.at[i,'VALUE'])
        # print(line)
        # print(sum%group)
        text_file = open(file, "a")
        # print(sum%group);
        text_file.write(line+"\n")
        text_file.close()
    return groupFiles,temppath

cur_path=os.path.dirname(os.path.realpath(__file__))
for file in entries:
    print("-------------------------------------------------------------------------------------------------")
    print(now_string+"  Start load meter readings defined in :"+file)
    print("-------------------------------------------------------------------------------------------------")

    groupFiles,groupfolder = _splitToGroups(file,siteid,thread,None)
    for gf in groupFiles:
        os.system('python3 '+cur_path+'/6.0_loadReading-per-groupfile.py '+orgid+' '+siteid+' '+gf+' '+str(batchSize)+' &')
    
    #Check last file is finished or not, if finished, then continue with next one.
    while True:
        if len(os.listdir(groupfolder)) != 0:
            sleep(3)
        else:
            print("End at :"+datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
            seconds = time() - start
            m, s = divmod(seconds, 60)
            print('Time taken: '+str(math.trunc(m))+" minutes"+" and "+str(math.ceil(s*100)/100)+" seconds")
            break;