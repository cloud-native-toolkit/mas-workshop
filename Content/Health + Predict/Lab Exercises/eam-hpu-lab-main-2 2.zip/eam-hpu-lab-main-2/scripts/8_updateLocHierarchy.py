import sys,os
import  api
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import time
import json 
import glob
import pandas as pd	
from datetime import datetime
import math

orgid=sys.argv[1]
siteid=sys.argv[2]
path = sys.argv[3]
locationAPI='MHOPERLOC'
batchSize=100
thread=1

entries = glob.glob(path+"/*.csv")

if len(sys.argv) > 5:
    print("Current now, thread parameter will be ignored for updating lochierachy for locations in one system")
    batchSize = int(sys.argv[5])


def bulk_create(items):
    arr=[]
    obj={}
    for item in items:
        obj={}
        obj_hier={}
        for key in item.keys():
            if key.upper() == 'PARENT':
                if item[key] == None:
                    obj_hier['parent'] = None
                    obj_hier['children'] = False
                else:
                    obj_hier['parent'] = item[key]
                    obj_hier['children'] = True
            elif key.upper() == 'LOCATION':
                obj_hier['location'] = item['LOCATION']
                obj['location'] = item['LOCATION']
            else:
                obj_hier[key.lower()]=item[key]
   

        obj_hier['siteid'] = siteid
        obj_hier['orgid'] = orgid

        obj['lochierarchy'] = obj_hier
        obj["siteid"]=siteid
        obj["orgid"]=orgid
        obj["_action"]='AddChange'
        # print(obj)
        arr.append(obj)
    # print(len(arr))
    # print(arr)
    # return ""

    res = api._maximo_bulk_create(mxapp=locationAPI, payload=arr)
    print("response status code : "+str(res.status_code))
    print(res.json())
    return res.status_code
    # return 200

now = datetime.now()
now_string = now.strftime("%d/%m/%Y %H:%M:%S")
start = time()

for file in entries:
    print("-------------------------------------------------------------------------------------------------")
    print("  Start update lochierachy for locations defined in :"+file)
    print("-------------------------------------------------------------------------------------------------")
    csv_file = pd.DataFrame(pd.read_csv(file, sep = ",", header = 0, index_col = False))	
    csv_file.to_json("./temp.json", orient = "records", date_format = "epoch", double_precision = 10, force_ascii = True, date_unit = "ms", default_handler = None)

    input_file = open("./temp.json")
    array = json.load(input_file)
    
    batch_list = [array[x:x+batchSize] for x in range(0, len(array),batchSize)]

    processes = []
    with ThreadPoolExecutor(max_workers=thread) as executor:
        for items in batch_list:
            processes.append(executor.submit(bulk_create, items))

    for task in as_completed(processes):
        if str(task.result()) != str(200):
            print(task.result())

print("Start at:"+now_string)	
print("End at :"+datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
seconds = time() - start
m, s = divmod(seconds, 60)
print('Time taken: '+str(math.trunc(m))+" minutes"+" and "+str(math.ceil(s*100)/100)+" seconds")
   
# #Clean 
os.remove("./temp.json")