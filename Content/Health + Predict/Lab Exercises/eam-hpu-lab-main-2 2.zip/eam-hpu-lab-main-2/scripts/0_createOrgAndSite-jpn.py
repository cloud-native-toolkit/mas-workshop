import sys,os
import  api

orgid=sys.argv[1]
siteid=sys.argv[2]

def create_orgid(orgid):
    description = orgid.upper() + ' Organization'
    companysetdesc = orgid.upper() + ' Company Set'
    itemsetdesc = orgid.upper() + ' Item Set'
    headers = {}
    headers['X-method-override'] = 'SYNC'
    headers['Content-Type'] = 'application/json'

    payload = {
                "enterdate":"&SYSDATE&",
                "description":description,
                "orgid": orgid,
                "basecurrency1":"USD",
                "companysetid":"T1CSET",
                "companysetdesc":companysetdesc,
                "enterby":"MAXREG",
                "dfltitemstatus":"アクティブ",
                "itemsetid":"T1SET",
                "itemsetdesc":itemsetdesc,
                "category":"在庫部品",
                "finperiod": "YEAR",
                "finmonth": "1",
                "finyears": 10
                ,
                "address":
                [
                    {
                        "address1":"100 Test Drive",
                        "address2":"Bedford",
                        "address3":"MA",
                        "address4":"01730",
                        "address5":"USA",
                        "addresscode":"Haspro"
                    } 
                ]
            }
    resp=api._call_maximo(
            '/os/mxapiorganization?lean=1',
            'post',
            payload,
            headers
        )
    if resp.status_code in [200,201,204]:
        print("Create org id step1 completed successfully")
    return resp

def create_org_glcomp(orgid):
    headers = {}
    headers['Content-Type'] = 'application/json'
    payload={
                "comptext": "Cost component",
                "glorder": 0,
                "active": True,
                "compvalue": "1000",
                "userid": "MAXREG",
                "orgid": orgid
    }
    resp=api._call_maximo(
            '/os/mxapiglcomp?lean=1',
            'post',
            payload,
            headers
        )
    if resp.status_code in [200,201]:
        print("Create org id step2 completed successfully")
    return resp

def create_org_coa(orgid):
    headers = {}
    headers['Content-Type'] = 'application/json'
    payload={
        "glaccount": "1000",
        "accountname": "Cost",
        "active": True,
        "glcomp01": "1000",
        "orgid": orgid,
        "activedate": "&SYSDATE&"
    }
    resp=api._call_maximo(
            '/os/mxapicoa?lean=1',
            'post',
            payload,
            headers
        )
    if resp.status_code in [200,201]:
        print("Create org id step3 completed successfully")
    return resp

def create_siteid(orgid,siteid):
    headers = {}
    headers['Content-Type'] = 'application/json'
    headers['X-method-override'] = 'SYNC'

    payload={
        "_action":"AddChange",
        "active":True,
        "orgid":orgid,
        "clearingacct":"1000",
        "site":[
            {
                "active":True,
                "enterby":"MAXREG",
                "enterdate":"&SYSDATE&",
                "description":siteid,
                "siteid":siteid,
                "billtoshipto":
                [
                    {
                    "shiptodefault": True,
                    "billto": True,
                    "billtodefault": True,
                    "addresscode": "Haspro",
                    "shipto": True
                    }
                ]
            }
        ]
    }
    resp=api._call_maximo(
            '/os/mxapiorganization?lean=1',
            'post',
            payload,
            headers
        )
    if resp.status_code in [200,201,204]:
        print("Create org id step4 completed successfully")
    return resp

resp=api._call_maximo(
            '/os/mxapiorganization?oslc.select=site&oslc.where=site.siteid="'+ siteid +'"',
            'get'
        )
if resp.status_code==200 and len(resp.json()['member']) == 0:
    resp=api._call_maximo(
            '/os/mxapiorganization?oslc.select=site&oslc.where=orgid="'+ orgid +'"',
            'get'
        )
    if resp.status_code==200 and len(resp.json()['member']) == 0:
        create_orgid(orgid)
        create_org_glcomp(orgid)
        create_org_coa(orgid)
    create_siteid(orgid,siteid)
else:
    exit(1)