import sys,os
import  api
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import time
import json 
import glob
import pandas as pd	
from datetime import datetime

orgid=sys.argv[1]
siteid=sys.argv[2]
path = sys.argv[3]
meterAPI='MHMETER'
meterGroupAPI='MHMETERGROUP'
entries = glob.glob(path+'/*.csv')

#Create meters
for file in entries:
    print("-------------------------------------------------------------------------------------------------")
    print("  Start load meters and meter groups defined in :"+file)
    print("-------------------------------------------------------------------------------------------------")

    csv_file = pd.DataFrame(pd.read_csv(file, sep = ",", header = 0, index_col = False))	
    csv_file.to_json("./temp.json", orient = "records", date_format = "epoch", double_precision = 10, force_ascii = True, date_unit = "ms", default_handler = None)

    input_file = open("./temp.json")
    array = json.load(input_file)
    # print(array)
    columns=csv_file.columns
    groups=csv_file['GROUPNAME'].unique()
    # print(groups)

    for g in groups:
        meteringroup=[]
        meterArray=[]
        for item in array:
            if g == item['GROUPNAME']:
                meteringroupObj={}
                meterObj={}
                for c in columns:
                    if c.upper() != 'GROUPNAME':
                        if item[c]!= None:
                            meterObj[c.lower()]=item[c]                  
                meterObj["_action"]='AddChange'              
                meterArray.append(meterObj)
                        
                meteringroupObj['metername']=item['METERNAME']
                meteringroup.append(meteringroupObj)
                            
        # print(meterArray)
        res=api._maximo_bulk_create(mxapp=meterAPI, payload=meterArray)
        print("response status code : "+str(res.status_code))
        print(res.json())

        #Create meterGroup
        meterGroupArr=[]
        meterGroup={}
        meterGroup['groupname']=g
        meterGroup['meteringroup']=meteringroup
        meterGroup["_action"]='AddChange'
        meterGroupArr.append(meterGroup)

        # print(meterGroup)
        res=api._maximo_bulk_create(mxapp=meterGroupAPI, payload=meterGroupArr)
        print("response status code : "+str(res.status_code))
        print(res.json())

#Clean 
os.remove("./temp.json")

