import sys,os
import  api
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import time
import json 
import glob
import pandas as pd	
from datetime import datetime

orgid=sys.argv[1]
siteid=sys.argv[2]
path = sys.argv[3]
unitAPI='MXAPIMEASUREUNIT'
classificationAPI='MHCLASSSTRUCTURELOAD'


entries = glob.glob(path+"/*.csv")
# print(entries)


#prepare classusewith
parms={'oslc.where':'domainid="CLASSUSEWITH"','maxdomain.synonymdomain.where':'maxvalue in ["ASSET","LOCATIONS"]','oslc.select':'*'}
classUseWith=api._maximo_query("MHDOMAIN",parms);
classUseWithObjTemp=classUseWith.json()['member'][0]['synonymdomain']
classUseWith=[]
for item in classUseWithObjTemp:
    obj={}
    obj['toplevel'] = False
    obj['objectvalue'] = item['value']
    if 'ASSET' in item['maxvalue']:
        obj['objectname'] = 'ASSET'
    if 'LOCATIONS' in item['maxvalue']:
        obj['objectname'] = 'LOCATIONS'	 		
    classUseWith.append(obj)
# print(classUseWith)

#create unit first
unitArray=[]
for file in entries:
    print("-------------------------------------------------------------------------------------------------")
    print("  First create units used by classifications defined in :"+file)
    print("-------------------------------------------------------------------------------------------------")

    csv_file = pd.DataFrame(pd.read_csv(file, sep = ",", header = 0, index_col = False))	
    csv_file.to_json("./temp.json", orient = "records", date_format = "epoch", double_precision = 10, force_ascii = True, date_unit = "ms", default_handler = None)

    input_file = open("./temp.json")
    array = json.load(input_file)
    # print(array)
    for attr in array:
        if attr['UNIT'] is not None:
            if attr['UNIT'] not in unitArray:
                # print(attr['UNIT'])
                unitArray.append(attr['UNIT'])
    unitArrayObj=[]
    for unit in unitArray:
        obj={}
        obj["measureunitid"]=unit
        obj["orgid"]=orgid
        unitArrayObj.append(obj)
    # print(unitArrayObj)
    res=api._maximo_bulk_create(mxapp=unitAPI, payload=unitArrayObj)
    print("response status code : "+str(res.status_code))
    print(res.json())

#Create classification
classificationArrayObj=[]
for file in entries:
    classification=os.path.splitext(os.path.basename(file))[0].upper()
    print("-------------------------------------------------------------------------------------------------")
    print("  Start load classification defined in :"+file)
    print("-------------------------------------------------------------------------------------------------")

    csv_file = pd.DataFrame(pd.read_csv(file, sep = ",", header = 0, index_col = False))
    classifications=csv_file['CLASSIFICATIONID'].unique()
    csv_file.to_json("./temp.json", orient = "records", date_format = "epoch", double_precision = 10, force_ascii = True, date_unit = "ms", default_handler = None)

    for c in classifications:
        input_file = open("./temp.json")
        array = json.load(input_file)
        obj={}
        obj['classificationid']=c    

        specObjArr=[]
        for item in array:
            # print(item)
            if(item['CLASSIFICATIONID'] == c):
                specObj={}
                specObj['assetattrid']=item['ASSETATTRID']
                specObj['datatype']=item['DATATYPE']
                if item['UNIT'] != None:
                    specObj['unit']=item['UNIT']
                specObjArr.append(specObj)
                if 'hierarchypath' in item and item['hierarchypath'] is not None:
                    obj['hierarchypath']=item['hierarchypath']
                else:
                    obj['hierarchypath']=item['CLASSIFICATIONID'].upper()
        obj['classspec']=specObjArr
        obj['siteid']=siteid
        obj['orgid']=orgid
        obj['classusewith']=classUseWith

        obj['_action']="AddChange"
        # print("------Process payload for classification: "+c)
        # print(obj)
        # print()


        classificationArrayObj.append(obj)
# print(classificationArrayObj)      
def divide_chunks(l, n): 
    for i in range(0, len(l), n):  
        yield l[i:i + n] 
n = 10
  
x = list(divide_chunks(classificationArrayObj, n)) 
# print (x) 
for l in x:
    res=api._maximo_bulk_create(mxapp=classificationAPI, payload=l)
    print("response status code : "+str(res.status_code))
    print(res.json())

os.remove("./temp.json")