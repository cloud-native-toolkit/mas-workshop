import logging
import logging.config
import os
import re

import requests
from requests_futures.sessions import FuturesSession
import numpy as np
import pandas as pd
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from os.path import exists
import shutil

logger = logging.getLogger(__name__)


global MX_BASE_URL,MX_API_CONTEXT,MX_USER,MX_PWD,MX_APIKEY
# MX_BASE_URL = 'http://health-team31.fyre.ibm.com:9084/maximo/'
MX_BASE_URL = None
MX_APIKEY = None
MX_USER = None
MX_PWD = None



def _call_maximo(url_path, method, json=None, headers=None, params=None, **kwargs):
    global MX_USER 
    global MX_PWD
    global MX_APIKEY
    global MX_BASE_URL

    if os.getenv('MX_BASE_URL') is not None and len(os.getenv('MX_BASE_URL'))!=0:
        MX_BASE_URL = os.environ['MX_BASE_URL']
    if os.getenv('MX_APIKEY') is not None and len(os.getenv('MX_APIKEY'))!=0:
        MX_APIKEY = os.environ['MX_APIKEY']
    if os.getenv('MX_USER')is not None and len(os.getenv('MX_USER'))!=0:
        MX_USER = os.environ['MX_USER']
    if os.getenv('MX_PWD') is not None and len(os.getenv('MX_PWD'))!=0:
        MX_PWD = os.environ['MX_PWD']

    url=""
    baseurl = MX_BASE_URL
    # print(baseurl)

    if headers is None:
        headers = {}

    if MX_APIKEY is None:
        api_context = 'oslc'
        # print(baseurl)
        url = '%s%s%s&%s&%s&%s' % (baseurl, api_context, url_path,'_lid='+MX_USER,'_lpwd='+MX_PWD,'lean=1')
        # print(url)
    else:
        api_context = 'api'
        headers['apikey']=MX_APIKEY
        url = '%s%s%s&%s' % (baseurl, api_context, url_path,'lean=1')
        # print(url)


    ssl_verify = False
    kwargs['ssl_verify'] = ssl_verify
    
    # print(url)
    # print(headers)
    # print(params)
    return _call(url=url, method=method, json=json, headers=headers, timeout=30000, params=params, **kwargs)


def _call(url, method, json=None, headers=None, params=None, **kwargs):
    return api_request(url, method=method, headers=headers, json=json, params=params, **kwargs)

def _maximo_bulk_create(mxapp, payload):
    headers = {
        'X-method-override': 'BULK',
        'PATCHTYPE':'MERGE',
        ## SET PROPERTIES for debugging if needed.
        # 'PROPERTIES':'*',
    } 
    # print(payload)
    if MX_APIKEY is not None:
        headers['apikey'] = MX_APIKEY
    # go ahead to create resources directly
    resp = _call_maximo(url_path='/os/%s?lean=1' % (mxapp), method='post', json=payload, headers=headers)
    return resp

def _maximo_create(mxapp, payload):
    # go ahead to create resources directly
    headers = {}
    if MX_APIKEY is not None:
        headers['apikey'] = MX_APIKEY
    resp = _call_maximo(url_path='/os/%s?lean=1' % (mxapp), method='post', json=payload, headers=headers)

    return resp

def _maximo_query(mxapp,params):
    # go ahead to create resources directly
    headers = {}
    if MX_APIKEY is not None:
        headers['apikey'] = MX_APIKEY
    resp = _call_maximo(url_path='/os/%s?lean=1' % (mxapp), method='get', params=params, headers=headers)

    return resp

def api_request(url, method='get', headers=None, json=None, timeout=None, ssl_verify=True, session=None, params=None,**kwargs):
    ssl_verify = False
    timeout=600
    logger.info('method=%s, url=%s, headers=%s, timeout=%s, ssl_verify=%s, json=%s, session=%s, kwargs=%s' % (method, url, str(headers), timeout, ssl_verify, str(json), str(session), str(kwargs)))

    r = requests if session is None else session

    if method == 'get':
        resp = r.get(url, headers=headers, verify=ssl_verify, json=json, timeout=timeout,params=params, **kwargs)
    elif method == 'post':
        resp = r.post(url, headers=headers, verify=ssl_verify, json=json, timeout=timeout,params=params, **kwargs)
    elif method == 'put':
        resp = r.put(url, headers=headers, verify=ssl_verify, json=json, timeout=timeout,params=params, **kwargs)
    elif method == 'patch':
        resp = r.patch(url, headers=headers, verify=ssl_verify, json=json, timeout=timeout,params=params, **kwargs)
    elif method == 'delete':
        resp = r.delete(url, headers=headers, verify=ssl_verify, json=json, timeout=timeout,params=params, **kwargs)
    else:
        raise ValueError('unsupported_method=%s' % method)

    if isinstance(r, FuturesSession):
        return resp

    logger.info('resp.status_code=%s, method=%s, url=%s' % (str(resp.status_code), method, url))

    if resp.status_code not in (requests.codes.ok, requests.codes.created, requests.codes.accepted, requests.codes.no_content):
        logger.warning('error api request: url=%s, method=%s, status_code=%s, response_text=%s' % (url, method, str(resp.status_code), str(resp.text)))
        return None

    return resp

