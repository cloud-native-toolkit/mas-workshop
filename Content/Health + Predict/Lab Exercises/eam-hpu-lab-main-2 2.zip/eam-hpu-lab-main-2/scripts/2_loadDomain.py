import sys,os
import  api
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import time
import json 
import glob
import pandas as pd	
from datetime import datetime

orgid=sys.argv[1]
siteid=sys.argv[2]
path = sys.argv[3]
domainAPI='MHDOMAIN'


parms={'oslc.select':'*','oslc.where':'domainid="DATATYPE"'}
resp=api._maximo_query("MHDOMAIN",parms);
datatypes=resp.json()['member'][0]['synonymdomain']

# print(datatypes)
alnString='ALN'
for dt in datatypes:
    # print(dt)
    # print()  
    if dt['maxvalue'] == 'ALN':
        alnString=dt['value']
# print(alnString)

entries = glob.glob(path+"/*.csv")
arrayObj=[]
for file in entries:
    # print(file)
    print("-------------------------------------------------------------------------------------------------")
    print("  Start load domains defined in :"+file)
    print("-------------------------------------------------------------------------------------------------")

    csv_file = pd.DataFrame(pd.read_csv(file, sep = ",", header = 0, index_col = False))	
    csv_file.to_json("./temp.json", orient = "records", date_format = "epoch", double_precision = 10, force_ascii = True, date_unit = "ms", default_handler = None)

    input_file = open("./temp.json")
    array = json.load(input_file)
    # DOMAINID,VALUE,MAXVALUE,DESCRIPTION
    columns=csv_file.columns
    if 'MAXVALUE' in columns:
        domain={}
        synonymdomain=[]
        for item in array:
            if item['DOMAINID'] == 'ASSETTYPE':
                obj={}
                for c in columns:
                    # print(c)
                    if(c.lower() != 'domainid'):
                        obj[c.lower()]=item[c]
                obj['_action']='AddChange'
                synonymdomain.append(obj)
        domain['domainid']='ASSETTYPE'
        domain['synonymdomain']=synonymdomain
        domain['_action']='AddChange'
        # print(domain)   
        arrayObj.append(domain)
        res=api._maximo_bulk_create(mxapp=domainAPI, payload=arrayObj)
        print("response status code : "+str(res.status_code))
        print(res.json())
    else:
        for item in array:
            if item['DOMAINTYPE'] == alnString:  #英数字
                alndomain=[]
                domainObj={}
                for c in columns:
                    # print(c)
                    if(c.lower() != 'domain'):
                        if item[c] is not None:
                            domainObj[c.lower()]=item[c]
                    else:
                        alndomain=[]
                        values=item[c].split(';')
                        for v in values:
                            obj={}
                            obj['value']=v
                            alndomain.append(obj)
                domainObj['_action']='AddChange'
                domainObj['alndomain']=alndomain
                arrayObj.append(domainObj)
        # print(arrayObj)
        res=api._maximo_bulk_create(mxapp=domainAPI, payload=arrayObj)
        print("response status code : "+str(res.status_code))
        print(res.json())

# #Clean 
os.remove("./temp.json")