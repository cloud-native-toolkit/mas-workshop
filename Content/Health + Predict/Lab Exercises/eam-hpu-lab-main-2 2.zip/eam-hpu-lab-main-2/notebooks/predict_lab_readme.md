## Predict notebooks hands-on lab

This simple lab illustrates how to transform the data, perform missing value analysis, followed by Auto imputation, train ML models on the dataset and build a PMI notebook resulting in a deployment in Monitor

1. Load the [kaggle pump dataset](https://www.kaggle.com/datasets/nphantawee/pump-sensor-data?resource=download)
2. Follow the instructions in the notebook `Kaggle_Pump_Data_Reindexing.ipynb` for transforming the data
3. Follow `Kaggle_Pump_Data_Imputation.ipynb` for Missing Value Analysis and Auto Imputatation
4. Train a Failure prediction model, and explore feature engineering techniques using `PumpFailureProbabilityPrediction.ipynb` notebook. This is WS notebook even though the file name doesn't reflect that
5. Refer to `Predict-Kaggle-Pump-Reindex-Imputed-V3.ipynb` notebook for applying the findings of WS notebook (in step 4) to PMI notebook. This notebook contains a data loader and multiple model training segments. Therefore that if you changed the name of the dataset or file in steps 1 to 4, then you need to use that dataset name in the data loader
