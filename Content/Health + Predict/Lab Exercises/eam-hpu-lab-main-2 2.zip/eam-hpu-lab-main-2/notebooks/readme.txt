1. Prepare hpu data zip and scripts zip file.
   Zip the hpu sample data and scripts into two zip.
   Sample data in https://github.ibm.com/Watson-IoT/eam-hpu-lab/tree/main/csv%20files
   Scripts in https://github.ibm.com/Watson-IoT/eam-hpu-lab/tree/main/scripts
   
   Command example:
   E.g cd <csv file root path, e.g /Users/gujuan/Documents/work/work/2022/lab/Github/eam-hpu-lab/csv\ files>
       zip -r hpu_csv_st.zip hpu_csv_st
       or zip -r hpu_csv_demo.zip hpu_csv_demo if use this dataset

       cd <scripts root path, e.g /Users/gujuan/Documents/work/work/2022/lab/Github/eam-hpu-lab/scripts>
       zip -r hpu_dataloader.zip *.py

   Note: the hpu sample data can be used for v87 and later.


2. Login cp4d, open ws project.
   Upload the hpu_dataloader.zip,  hpu_csv_st.zip into data asset.
   Upload three hpu_st_*****.csv files under https://github.ibm.com/Watson-IoT/eam-hpu-lab/tree/main/csv%20files/predict_csv_st into data asset.
   Upload below notebooks under eam-hpu-lab/notebooks into ws project, notebooks in https://github.ibm.com/Watson-IoT/eam-hpu-lab/tree/main/notebooks.
      0_HPU-DataLoader.ipynb
      1_Create-HPU-ScoreGroups.ipynb
      1.2_Create-PUMP-SG_CustomScoreType.ipynb
      1.3_Create-ST-SG_FutureScores.ipynb
      2_FastStartLoader-Predict.ipynb
      3_PMI - Anomaly Detection -UnSupervised-HPU.ipynb
      4_PMI - End of Life Curve HPU.ipynb
      5_PMI - Predicted Failure Date-Smart Regression-HPU.ipynb
      6_PMI-Failure Probability-BinaryClassification-HPU.ipynb
      IBM-future-score-from-csv-sample-6.0.0-demo.ipynb

   Upload the below model cfg files into data asset in configured hpu project, choose overwrite existing file and submit.
      IBM-Transformers-Tap-Changers-DGA-6.0.0.cfg
      IBM-future-score-from-csv-sample-6.0.0-demo.cfg

   Open notebook IBM-future-score-from-csv-sample-6.0.0-demo.ipynb,save a version and then create a job Run-IBM-future-score-from-csv-sample-6-0-0-demo for this notebook, and bind to the latest version.

3. Run below notebooks to load data one by one
   a). 0_HPU-DataLoader.ipynb to load asset and location metadata
   Update os.environ['ORGID'],  os.environ['SITEID'] if want use a different org and site,
   Prepare HPU_Envs.json by following the instructions in notebook, and upload to the data asset.

   Note: if you reuse the sample st csv files, leave the os.environ['DATA_PATH'], os.environ['DATA_LOADER_PATH'] as it is. 
         Otherwise, will need update the environment variables and the first cell to extract the zip files, make sure you point to the right path of the scripts and the csv files.
          
         Reference: https://mam-hol.eu-gb.mybluemix.net/apm_8.7/utilities_score_notebook/
   
   b).1_Create-HPU-ScoreGroups.ipynb to create query and score groups.
   Prepare HPU_Envs.json same as 3.a,  site_id used in 3.a, model_version(same version as on UI,e.g for MAS8.7 model_version is 4.0.0,MAS8.9 model_version is 6.0.0) values.
   
   Optional:Update ASSET_CLASS if needed based on the data loaded in 3.a. E.g ASSET_CLASS has thress samples, when only load data for Substation Transformer, use first ASSET_CLASS sample, when using the demo data set, use second ASSET_CLASS sample. 
   
   Reference: https://mam-hol.eu-gb.mybluemix.net/apm_8.7/utilities_score_notebook/

   If you have pump data loaded which included in hpu_csv_demo, run 1.2_Create-PUMP-SG_CustomScoreType.ipynb to create a pump score group using custom score type.
   If you want show some future score capability in matrix, run 1.3_Create-ST-SG_FutureScores.ipynb.
   
   c).Open 2_FastStartLoader-Predict.ipynb
      i) Upload monitor db cert into the project data asset. 
         Reference:https://mam-hol.eu-gb.mybluemix.net/apm_8.7/setup_watson_studio/#setup-database-connection-in-watson-studio
      ii) Prepare the Predict_Envs.json, and upload into the project data asset. Details can be checked in this notebook cell "1.2 Install Maximo-Predict SDK and initialize system"
      iii) Change default_site_id to the site which data is loaded in 3.a. If it's for other asset type, please also change newAssetPrefix.
      E.g,
           default_site_id = 'EUDEMO'
           newAssetPrefix='ST'
   Reference: https://mam-hol.eu-gb.mybluemix.net/apm_8.7/utilities_devicedata/

4. Run the predict model notebook to train predict models one by one.
   Reference:
      https://mam-hol.eu-gb.mybluemix.net/apm_8.7/utilities_anomaly_detection/
      https://mam-hol.eu-gb.mybluemix.net/apm_8.7/utilities_EOL/
      https://mam-hol.eu-gb.mybluemix.net/apm_8.7/utilities_Failure_date/
      https://mam-hol.eu-gb.mybluemix.net/apm_8.7/utilities_Failure_Probability/

5. Verify, search or filter the asset e.g ST_1393137, click on asset go to asset detail page. Check predictions section for predicts charts.

6. Click recalculate scores on score setup UI for the HPU scoregroup created in 3.b, skip this step if already done.